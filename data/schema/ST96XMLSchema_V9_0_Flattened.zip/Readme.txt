Total Number of Namespace Monolithic Schemas: 7
1. Common_V9_0.xsd [888  Files -> 615  Components]
    +--OASISTable_V1_0.xsd
    +--FlattenedMathML2Edition2.xsd

2. Copyright_V9_0.xsd [89  Files -> 54  Components]
    +--Common_V9_0.xsd

3. Design_V9_0.xsd [511  Files -> 292  Components]
    +--Common_V9_0.xsd

4. ExternalStandards [1  File -> 1  Component]
    +--Common_V9_0.xsd

5. GeographicalIndication_V9_0.xsd [251  Files -> 174  Components]
    +--Common_V9_0.xsd
    +--Trademark_V9_0.xsd

6. Patent_V9_0.xsd [824  Files -> 526  Components]
    +--Common_V9_0.xsd
    +--Design_V9_0.xsd

7. Trademark_V9_0.xsd [912  Files -> 581  Components]
    +--Common_V9_0.xsd


Total Number of Flattened Schemas: 36
1. CopyrightOrphanWork_V9_0.xsd dependency details:
CopyrightOrphanWork_V9_0.xsd [91  Files -> 55  Components]
  +--CopyrightOrphanWork_V9_0_Common.xsd [397  Files -> 253  Components]
    +--OASISTable_V1_0.xsd
    +--FlattenedMathML2Edition2.xsd

2. DesignApplication_V9_0.xsd dependency details:
DesignApplication_V9_0.xsd [182  Files -> 117  Components]
  +--DesignApplication_V9_0_Common.xsd [621  Files -> 410  Components]
    +--OASISTable_V1_0.xsd
    +--FlattenedMathML2Edition2.xsd

3. DesignApplicationBag_V9_0.xsd dependency details:
DesignApplicationBag_V9_0.xsd [184  Files -> 118  Components]
  +--DesignApplicationBag_V9_0_Common.xsd [621  Files -> 410  Components]
    +--OASISTable_V1_0.xsd
    +--FlattenedMathML2Edition2.xsd

4. DesignLegalStatusData_V9_0.xsd dependency details:
DesignLegalStatusData_V9_0.xsd [347  Files -> 203  Components]
  +--DesignLegalStatusData_V9_0_Common.xsd [636  Files -> 429  Components]
    +--OASISTable_V1_0.xsd
    +--FlattenedMathML2Edition2.xsd

5. DesignTransaction_V9_0.xsd dependency details:
DesignTransaction_V9_0.xsd [245  Files -> 150  Components]
  +--DesignTransaction_V9_0_Common.xsd [721  Files -> 483  Components]
    +--OASISTable_V1_0.xsd
    +--FlattenedMathML2Edition2.xsd

6. DesignTransactionBody_V9_0.xsd dependency details:
DesignTransactionBody_V9_0.xsd [243  Files -> 149  Components]
  +--DesignTransactionBody_V9_0_Common.xsd [700  Files -> 466  Components]
    +--OASISTable_V1_0.xsd
    +--FlattenedMathML2Edition2.xsd

7. HagueIBToOfficeTransaction_V9_0.xsd dependency details:
HagueIBToOfficeTransaction_V9_0.xsd [247  Files -> 137  Components]
  +--HagueIBToOfficeTransaction_V9_0_Common.xsd [521  Files -> 339  Components]
    +--OASISTable_V1_0.xsd
    +--FlattenedMathML2Edition2.xsd

8. HagueOfficeToIBTransaction_V9_0.xsd dependency details:
HagueOfficeToIBTransaction_V9_0.xsd [153  Files -> 90  Components]
  +--HagueOfficeToIBTransaction_V9_0_Common.xsd [563  Files -> 368  Components]
    +--OASISTable_V1_0.xsd
    +--FlattenedMathML2Edition2.xsd

9. DGN_TransactionContentBag_V9_0.xsd dependency details:
DGN_TransactionContentBag_V9_0.xsd [241  Files -> 148  Components]
  +--DGN_TransactionContentBag_V9_0_Common.xsd [694  Files -> 462  Components]
    +--OASISTable_V1_0.xsd
    +--FlattenedMathML2Edition2.xsd

10. DGN_TransactionData_V9_0.xsd dependency details:
DGN_TransactionData_V9_0.xsd [239  Files -> 147  Components]
  +--DGN_TransactionData_V9_0_Common.xsd [688  Files -> 459  Components]
    +--OASISTable_V1_0.xsd
    +--FlattenedMathML2Edition2.xsd

11. GIApplication_V9_0.xsd dependency details:
GIApplication_V9_0.xsd [154  Files -> 115  Components]
  +--GIApplication_V9_0_Common.xsd [490  Files -> 315  Components]
    +--OASISTable_V1_0.xsd
    +--FlattenedMathML2Edition2.xsd

12. GITransaction_V9_0.xsd dependency details:
GITransaction_V9_0.xsd [226  Files -> 160  Components]
  +--GITransaction_V9_0_Common.xsd [532  Files -> 346  Components]
    +--OASISTable_V1_0.xsd
    +--FlattenedMathML2Edition2.xsd
  +--GITransaction_V9_0_Trademark.xsd [7  Files -> 5  Components]
    +--GITransaction_V9_0_Common.xsd

13. GITransactionBody_V9_0.xsd dependency details:
GITransactionBody_V9_0.xsd [224  Files -> 159  Components]
  +--GITransactionBody_V9_0_Common.xsd [511  Files -> 329  Components]
    +--OASISTable_V1_0.xsd
    +--FlattenedMathML2Edition2.xsd
  +--GITransactionBody_V9_0_Trademark.xsd [7  Files -> 5  Components]
    +--GITransactionBody_V9_0_Common.xsd

14. LisbonRecordBag_V9_0.xsd dependency details:
LisbonRecordBag_V9_0.xsd [168  Files -> 119  Components]
  +--LisbonRecordBag_V9_0_Common.xsd [420  Files -> 271  Components]
    +--OASISTable_V1_0.xsd
    +--FlattenedMathML2Edition2.xsd

15. GIN_TransactionContentBag_V9_0.xsd dependency details:
GIN_TransactionContentBag_V9_0.xsd [222  Files -> 158  Components]
  +--GIN_TransactionContentBag_V9_0_Common.xsd [505  Files -> 325  Components]
    +--OASISTable_V1_0.xsd
    +--FlattenedMathML2Edition2.xsd
  +--GIN_TransactionContentBag_V9_0_Trademark.xsd [7  Files -> 5  Components]
    +--GIN_TransactionContentBag_V9_0_Common.xsd

16. GIN_TransactionData_V9_0.xsd dependency details:
GIN_TransactionData_V9_0.xsd [220  Files -> 157  Components]
  +--GIN_TransactionData_V9_0_Common.xsd [499  Files -> 322  Components]
    +--OASISTable_V1_0.xsd
    +--FlattenedMathML2Edition2.xsd
  +--GIN_TransactionData_V9_0_Trademark.xsd [7  Files -> 5  Components]
    +--GIN_TransactionData_V9_0_Common.xsd

17. ApplicationBody_V9_0.xsd dependency details:
ApplicationBody_V9_0.xsd [69  Files -> 48  Components]
  +--ApplicationBody_V9_0_Common.xsd [355  Files -> 224  Components]
    +--OASISTable_V1_0.xsd
    +--FlattenedMathML2Edition2.xsd

18. BibliographicData_V9_0.xsd dependency details:
BibliographicData_V9_0.xsd [412  Files -> 264  Components]
  +--BibliographicData_V9_0_Common.xsd [457  Files -> 299  Components]
    +--OASISTable_V1_0.xsd
    +--FlattenedMathML2Edition2.xsd

19. DesignPatent_V9_0.xsd dependency details:
DesignPatent_V9_0.xsd [74  Files -> 49  Components]
  +--DesignPatent_V9_0_Design.xsd [37  Files -> 22  Components]
    +--DesignPatent_V9_0_Common.xsd
  +--DesignPatent_V9_0_Common.xsd [434  Files -> 275  Components]
    +--OASISTable_V1_0.xsd
    +--FlattenedMathML2Edition2.xsd

20. DesignPatentBag_V9_0.xsd dependency details:
DesignPatentBag_V9_0.xsd [76  Files -> 50  Components]
  +--DesignPatentBag_V9_0_Design.xsd [37  Files -> 22  Components]
    +--DesignPatentBag_V9_0_Common.xsd
  +--DesignPatentBag_V9_0_Common.xsd [434  Files -> 275  Components]
    +--OASISTable_V1_0.xsd
    +--FlattenedMathML2Edition2.xsd

21. DesignPatentBibliographicData_V9_0.xsd dependency details:
DesignPatentBibliographicData_V9_0.xsd [103  Files -> 59  Components]
  +--DesignPatentBibliographicData_V9_0_Design.xsd [1  File -> 1  Component]
  +--DesignPatentBibliographicData_V9_0_Common.xsd [383  Files -> 245  Components]
    +--OASISTable_V1_0.xsd
    +--FlattenedMathML2Edition2.xsd

22. DesignPatentPublication_V9_0.xsd dependency details:
DesignPatentPublication_V9_0.xsd [162  Files -> 98  Components]
  +--DesignPatentPublication_V9_0_Design.xsd [38  Files -> 23  Components]
    +--DesignPatentPublication_V9_0_Common.xsd
  +--DesignPatentPublication_V9_0_Common.xsd [464  Files -> 299  Components]
    +--OASISTable_V1_0.xsd
    +--FlattenedMathML2Edition2.xsd

23. ExaminationReport_V9_0.xsd dependency details:
ExaminationReport_V9_0.xsd [249  Files -> 162  Components]
  +--ExaminationReport_V9_0_Common.xsd [423  Files -> 268  Components]
    +--OASISTable_V1_0.xsd
    +--FlattenedMathML2Edition2.xsd

24. PatentLegalStatusData_V9_0.xsd dependency details:
PatentLegalStatusData_V9_0.xsd [314  Files -> 190  Components]
  +--PatentLegalStatusData_V9_0_Common.xsd [516  Files -> 342  Components]
    +--OASISTable_V1_0.xsd
    +--FlattenedMathML2Edition2.xsd

25. PatentPublication_V9_0.xsd dependency details:
PatentPublication_V9_0.xsd [466  Files -> 301  Components]
  +--PatentPublication_V9_0_Common.xsd [468  Files -> 308  Components]
    +--OASISTable_V1_0.xsd
    +--FlattenedMathML2Edition2.xsd

26. SearchReport_V9_0.xsd dependency details:
SearchReport_V9_0.xsd [365  Files -> 230  Components]
  +--SearchReport_V9_0_Common.xsd [445  Files -> 282  Components]
    +--OASISTable_V1_0.xsd
    +--FlattenedMathML2Edition2.xsd

27. SPCBibliographicData_V9_0.xsd dependency details:
SPCBibliographicData_V9_0.xsd [72  Files -> 45  Components]
  +--SPCBibliographicData_V9_0_Common.xsd [393  Files -> 253  Components]
    +--OASISTable_V1_0.xsd
    +--FlattenedMathML2Edition2.xsd

28. Article6terPublicationBag_V9_0.xsd dependency details:
Article6terPublicationBag_V9_0.xsd [52  Files -> 33  Components]
  +--Article6terPublicationBag_V9_0_Common.xsd [395  Files -> 250  Components]
    +--OASISTable_V1_0.xsd
    +--FlattenedMathML2Edition2.xsd

29. MadridIBToOfficeTransaction_V9_0.xsd dependency details:
MadridIBToOfficeTransaction_V9_0.xsd [388  Files -> 251  Components]
  +--MadridIBToOfficeTransaction_V9_0_Common.xsd [571  Files -> 379  Components]
    +--OASISTable_V1_0.xsd
    +--FlattenedMathML2Edition2.xsd

30. MadridOfficeToIBTransaction_V9_0.xsd dependency details:
MadridOfficeToIBTransaction_V9_0.xsd [699  Files -> 465  Components]
  +--MadridOfficeToIBTransaction_V9_0_Common.xsd [638  Files -> 430  Components]
    +--OASISTable_V1_0.xsd
    +--FlattenedMathML2Edition2.xsd

31. TrademarkApplication_V9_0.xsd dependency details:
TrademarkApplication_V9_0.xsd [578  Files -> 398  Components]
  +--TrademarkApplication_V9_0_Common.xsd [648  Files -> 435  Components]
    +--OASISTable_V1_0.xsd
    +--FlattenedMathML2Edition2.xsd

32. TrademarkLegalStatusData_V9_0.xsd dependency details:
TrademarkLegalStatusData_V9_0.xsd [335  Files -> 217  Components]
  +--TrademarkLegalStatusData_V9_0_Common.xsd [607  Files -> 405  Components]
    +--OASISTable_V1_0.xsd
    +--FlattenedMathML2Edition2.xsd

33. TrademarkTransaction_V9_0.xsd dependency details:
TrademarkTransaction_V9_0.xsd [629  Files -> 427  Components]
  +--TrademarkTransaction_V9_0_Common.xsd [688  Files -> 464  Components]
    +--OASISTable_V1_0.xsd
    +--FlattenedMathML2Edition2.xsd

34. TrademarkTransactionBody_V9_0.xsd dependency details:
TrademarkTransactionBody_V9_0.xsd [627  Files -> 426  Components]
  +--TrademarkTransactionBody_V9_0_Common.xsd [667  Files -> 447  Components]
    +--OASISTable_V1_0.xsd
    +--FlattenedMathML2Edition2.xsd

35. TMK_TransactionContentBag_V9_0.xsd dependency details:
TMK_TransactionContentBag_V9_0.xsd [625  Files -> 425  Components]
  +--TMK_TransactionContentBag_V9_0_Common.xsd [661  Files -> 443  Components]
    +--OASISTable_V1_0.xsd
    +--FlattenedMathML2Edition2.xsd

36. TMK_TransactionData_V9_0.xsd dependency details:
TMK_TransactionData_V9_0.xsd [623  Files -> 424  Components]
  +--TMK_TransactionData_V9_0_Common.xsd [655  Files -> 440  Components]
    +--OASISTable_V1_0.xsd
    +--FlattenedMathML2Edition2.xsd

